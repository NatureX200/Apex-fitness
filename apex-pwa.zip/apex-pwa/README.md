# ⚡ APEX Dark Edition — PWA

A standalone fitness dashboard that installs directly to your iPhone or iPad Home Screen — **no App Store, no Claude.ai login needed**.

---

## 🚀 Deploy to GitHub Pages (5 minutes)

### Step 1 — Create a GitHub repo

1. Go to **github.com** → click **New repository**
2. Name it anything, e.g. `apex-fitness`
3. Set it to **Public** (required for free GitHub Pages)
4. Click **Create repository**

### Step 2 — Upload these files

**Option A — Drag & Drop (easiest):**
1. Open your new repo on GitHub
2. Click **"uploading an existing file"**
3. Drag the entire contents of this folder into the window
4. Click **Commit changes**

**Option B — Git CLI:**
```bash
cd apex-pwa
git init
git add .
git commit -m "Initial APEX PWA"
git remote add origin https://github.com/YOUR_USERNAME/apex-fitness.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages

1. Go to your repo → **Settings** → **Pages**
2. Under **Source**, select **GitHub Actions**
3. The workflow will run automatically and give you a URL like:
   `https://your-username.github.io/apex-fitness/`

---

## 📱 Install on iPhone / iPad

1. Open the GitHub Pages URL in **Safari** (must be Safari)
2. Tap the **Share button** (⎋) at the bottom of the screen
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **Add**
5. APEX now appears on your Home Screen as a full app — no browser chrome, no Claude login!

---

## 🤖 Install on Android

1. Open the URL in **Chrome**
2. Tap the **three dots menu** (⋮)
3. Tap **"Add to Home Screen"** or **"Install App"**
4. Done!

---

## ✅ Features

- Works **100% offline** after first load (Service Worker cached)
- **Full screen** — no Safari address bar or navigation chrome
- **Custom splash screen** on launch for iPhone/iPad
- **App icon** on Home Screen (APEX logo)
- Installable on iOS 16.4+ and Android Chrome

---

## 📁 File Structure

```
apex-pwa/
├── index.html          ← Main app (all-in-one HTML/CSS/JS)
├── manifest.json       ← PWA manifest (name, icon, colors)
├── sw.js               ← Service Worker (offline support)
├── icons/
│   ├── icon-96.png
│   ├── icon-152.png
│   ├── icon-167.png
│   ├── icon-180.png    ← Apple Touch Icon
│   ├── icon-192.png    ← Android icon
│   ├── icon-512.png    ← Large icon
│   └── splash-*.png   ← iOS launch screens
└── .github/
    └── workflows/
        └── deploy.yml  ← Auto-deploy to GitHub Pages
```
